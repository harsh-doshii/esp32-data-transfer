package com.example.markone;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.os.AsyncTask;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.messaging.FirebaseMessaging;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URI;
import java.net.URL;

public class MainActivity extends AppCompatActivity {

    private static final String SERVER_URL = "http://192.168.4.1";

    private Button monitorButton;
    private WebView webView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        webView = findViewById(R.id.webView);

        // Enable JavaScript (required for Chart.js)
        WebSettings webSettings = webView.getSettings();
        webSettings.setJavaScriptEnabled(true);

        // Load the HTML content into the WebView
        String htmlContent = "<!DOCTYPE html>\n" +
                "<html>\n" +
                "<head>\n" +
                "    <title>Time-Series Data Plot</title>\n" +
                "    <!-- Include Chart.js library -->\n" +
                "    <script src=\"https://cdn.jsdelivr.net/npm/chart.js\"></script>\n" +
                "</head>\n" +
                "<body>\n" +
                "    <h1>Time-Series Data Plot</h1>\n" +
                "    <canvas id=\"dataChart\" width=\"800\" height=\"400\"></canvas>\n" +
                "    <button id=\"startButton\">Start Receiving Data</button>\n" +
                "    <button id=\"stopButton\">Stop Receiving Data</button>\n" +
                "    <button id=\"clearButton\">Clear Chart</button>\n" +
                " \n" +
                "    <script>\n" +
                "        // Initialize an empty array to store the data\n" +
                "        var data = [];\n" +
                "        var receivingData = false; // Flag to control data reception\n" +
                " \n" +
                " \n" +
                "        // Get a reference to the canvas element\n" +
                "        var ctx = document.getElementById('dataChart').getContext('2d');\n" +
                " \n" +
                "        // Create a new Chart instance\n" +
                "        var chart = new Chart(ctx, {\n" +
                "            type: 'line',\n" +
                "            data: {\n" +
                "                labels: [], // Timestamps will be added dynamically\n" +
                "                datasets: [{\n" +
                "                    label: 'Datapoint',\n" +
                "                    data: data,\n" +
                "                    borderColor: 'blue',\n" +
                "                    borderWidth: 1,\n" +
                "                    fill: false\n" +
                "                }]\n" +
                "            },\n" +
                "            options: {\n" +
                "                responsive: true,\n" +
                "                scales: {\n" +
                "                    x: [{\n" +
                "                        type: 'time',\n" +
                "                        time: {\n" +
                "                            unit: 'second' // You can adjust the time scale as needed\n" +
                "                        }\n" +
                "                    }],\n" +
                "                    y: [{\n" +
                "                        ticks: {\n" +
                "                            beginAtZero: true,\n" +
                "                            stepSize: 1\n" +
                "                        }\n" +
                "                    }]\n" +
                "                }\n" +
                "            }\n" +
                "        });\n" +
                " \n" +
                "        function startReceivingData() {\n" +
                "            receivingData = true;\n" +
                "            document.getElementById('startButton').disabled = true;\n" +
                "            document.getElementById('stopButton').disabled = false;\n" +
                "            receiveAndPlotData();\n" +
                " \n" +
                "        }\n" +
                " \n" +
                "        function stopReceivingData() {\n" +
                "            receivingData = false;\n" +
                "            document.getElementById('startButton').disabled = false;\n" +
                "            document.getElementById('stopButton').disabled = true;\n" +
                "        }\n" +
                " \n" +
                "        function clearChart() {\n" +
                "            chart.data.labels = [];\n" +
                "            chart.data.datasets[0].data = [];\n" +
                "            chart.update();\n" +
                "        }\n" +
                " \n" +
                "        document.getElementById('startButton').addEventListener('click', startReceivingData);\n" +
                "        document.getElementById('stopButton').addEventListener('click', stopReceivingData);\n" +
                "        document.getElementById('clearButton').addEventListener('click', clearChart);\n" +
                " \n" +
                " \n" +
                " \n" +
                "        // Function to add data points to the chart\n" +
                "        function addDataPoint(timestamp, value) {\n" +
                "            // Add the timestamp to the labels\n" +
                "            chart.data.labels.push(timestamp);\n" +
                " \n" +
                "            // Add the value to the dataset\n" +
                "            chart.data.datasets[0].data.push(value);\n" +
                " \n" +
                "            // Update the chart\n" +
                "            chart.update();\n" +
                "        }\n" +
                " \n" +
                "        // Function to receive data from the ESP32 server and plot it\n" +
                "        function receiveData(dataString) {\n" +
                "            // Parse the dataString as JSON\n" +
                "            var jsonData = JSON.parse(dataString);\n" +
                " \n" +
                "            // Extract the timestamp and value from the JSON data\n" +
                "            var timestamp = new Date(jsonData.data[0]); // Assuming the timestamp is the first element\n" +
                "            var value = jsonData.data[1]; // Assuming the value is the second element\n" +
                " \n" +
                "            // Add the data point to the chart\n" +
                "            addDataPoint(timestamp, value);\n" +
                "        }\n" +
                " \n" +
                "        // Sample function to simulate receiving data (replace with actual data reception)\n" +
                "        function simulateDataReception() {\n" +
                "            setInterval(function () {\n" +
                "                if (!receivingData) {\n" +
                "                    return; // Stop receiving data if the flag is set to false\n" +
                "                }\n" +
                " \n" +
                "                // Simulate receiving data from the ESP32 server (replace with actual data reception)\n" +
                "                var dataString = '{\"data\": [' + Date.now() + ', ' + Math.round(Math.random()) + ']}';\n" +
                " \n" +
                "                // Call the receiveData function with the received data\n" +
                "                receiveData(dataString);\n" +
                "            }, 1000); // Adjust the interval as needed\n" +
                "        }\n" +
                " \n" +
                " \n" +
                "        function receiveAndPlotData() {\n" +
                "            // Make an HTTP GET request to fetch data from the ESP32 server\n" +
                "            fetch('http://192.168.4.1/final')\n" +
                "                .then(response => response.json())\n" +
                "                .then(data => {\n" +
                "                    // Extract timestamp and value from the JSON response\n" +
                "                    var timestamp = data.data[0];\n" +
                "                    var value = data.data[1];\n" +
                " \n" +
                "                    // Add the data point to the chart\n" +
                "                    addDataPoint(timestamp, value);\n" +
                " \n" +
                "                    // Continue fetching and plotting data if the flag is set to true\n" +
                "                    if (receivingData) {\n" +
                "                        receiveAndPlotData();\n" +
                "                    }\n" +
                "                })\n" +
                "                .catch(error => {\n" +
                "                    console.error('Error fetching data:', error);\n" +
                "                });\n" +
                "        }\n" +
                " \n" +
                " \n" +
                "        startReceivingData();\n" +
                "        // Start simulating data reception (remove if using real data)\n" +
                "        receiveAndPlotData();\n" +
                "    </script>\n" +
                "</body>\n" +
                "</html>"; // Paste your HTML code here
        webView.loadDataWithBaseURL(null, htmlContent, "text/html", "UTF-8", null);

        // Ensure links and redirects open in the WebView, not in the browser
        webView.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView view, String url) {
                view.loadUrl(url);
                return true;
            }
        });
    }

    // Handle back button navigation
    @Override
    public void onBackPressed() {
        if (webView.canGoBack()) {
            webView.goBack();
        } else {
            super.onBackPressed();
        }
    }


}